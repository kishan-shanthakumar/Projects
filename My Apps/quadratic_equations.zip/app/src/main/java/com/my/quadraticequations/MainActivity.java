package com.my.quadraticequations;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.app.Activity;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Button;
import android.widget.EditText;
import android.content.SharedPreferences;
import android.view.View;
import java.text.DecimalFormat;

public class MainActivity extends Activity {
	
	
	private double a = 0;
	private double b = 0;
	private double c = 0;
	private double d = 0;
	private double x1 = 0;
	private double x2 = 0;
	private String d1 = "";
	private String x11 = "";
	private String x21 = "";
	private String a1 = "";
	private String b1 = "";
	private String c1 = "";
	
	private LinearLayout linear1;
	private ScrollView vscroll6;
	private LinearLayout linear15;
	private TextView textview19;
	private TextView textview17;
	private TextView textview4;
	private LinearLayout linear18;
	private TextView textview5;
	private LinearLayout linear19;
	private TextView textview6;
	private LinearLayout linear20;
	private Button run;
	private LinearLayout linear17;
	private LinearLayout linear16;
	private LinearLayout layout1;
	private EditText value_of_a;
	private TextView iva;
	private EditText value_of_b;
	private TextView ivb;
	private EditText value_of_c;
	private TextView ivc;
	private TextView textview21;
	private TextView remarks;
	private TextView textview7;
	private TextView discriminant;
	private LinearLayout linear9;
	private LinearLayout linear10;
	private TextView textview10;
	private TextView root1;
	private TextView textview11;
	private TextView root2;
	
	private SharedPreferences f;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize();
		initializeLogic();
	}
	
	private void initialize() {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		vscroll6 = (ScrollView) findViewById(R.id.vscroll6);
		linear15 = (LinearLayout) findViewById(R.id.linear15);
		textview19 = (TextView) findViewById(R.id.textview19);
		textview17 = (TextView) findViewById(R.id.textview17);
		textview4 = (TextView) findViewById(R.id.textview4);
		linear18 = (LinearLayout) findViewById(R.id.linear18);
		textview5 = (TextView) findViewById(R.id.textview5);
		linear19 = (LinearLayout) findViewById(R.id.linear19);
		textview6 = (TextView) findViewById(R.id.textview6);
		linear20 = (LinearLayout) findViewById(R.id.linear20);
		run = (Button) findViewById(R.id.run);
		linear17 = (LinearLayout) findViewById(R.id.linear17);
		linear16 = (LinearLayout) findViewById(R.id.linear16);
		layout1 = (LinearLayout) findViewById(R.id.layout1);
		value_of_a = (EditText) findViewById(R.id.value_of_a);
		iva = (TextView) findViewById(R.id.iva);
		value_of_b = (EditText) findViewById(R.id.value_of_b);
		ivb = (TextView) findViewById(R.id.ivb);
		value_of_c = (EditText) findViewById(R.id.value_of_c);
		ivc = (TextView) findViewById(R.id.ivc);
		textview21 = (TextView) findViewById(R.id.textview21);
		remarks = (TextView) findViewById(R.id.remarks);
		textview7 = (TextView) findViewById(R.id.textview7);
		discriminant = (TextView) findViewById(R.id.discriminant);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		textview10 = (TextView) findViewById(R.id.textview10);
		root1 = (TextView) findViewById(R.id.root1);
		textview11 = (TextView) findViewById(R.id.textview11);
		root2 = (TextView) findViewById(R.id.root2);
		f = getSharedPreferences("abc", Activity.MODE_PRIVATE);
		
		run.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				if (((value_of_a.getText().toString().length() > 0) && (value_of_b.getText().toString().length() > 0)) && (value_of_c.getText().toString().length() > 0)) {
					a1 = value_of_a.getText().toString();
					a = Double.parseDouble(a1);
					if (a == 0) {
						SketchwareUtil.showMessage(getApplicationContext(), "Enter proper equation");
					}
					else {
						b1 = value_of_b.getText().toString();
						b = Double.parseDouble(b1);
						c1 = value_of_c.getText().toString();
						c = Double.parseDouble(c1);
						d = (b * b) - (4 * (a * c));
						d1 = String.valueOf(d);
						discriminant.setText(d1);
						if (d < 0) {
							remarks.setText("Imaginary Roots");
							root1.setText(String.valueOf((0 - b) / (2 * a)).concat("+").concat(String.valueOf(Math.sqrt(0 - d) / (2 * a)).concat("i")));
							root2.setText(String.valueOf((0 - b) / (2 * a)).concat("-").concat(String.valueOf(Math.sqrt(0 - d) / (2 * a)).concat("i")));
						}
						else {
							remarks.setText("Real Roots");
							if (d > 0) {
								x1 = ((0 - b) / (2 * a)) + (Math.sqrt(d) / (2 * a));
								x2 = ((0 - b) / (2 * a)) - (Math.sqrt(d) / (2 * a));
							}
							else {
								x1 = (0 - b) / (2 * a);
								x2 = (0 - b) / (2 * a);
							}
							x11 = String.valueOf(x1);
							x21 = String.valueOf(x2);
							root1.setText(x11);
							root2.setText(x21);
						}
					}
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "Enter all the values and then press enter");
				}
			}
		});
	}
	private void initializeLogic() {
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
