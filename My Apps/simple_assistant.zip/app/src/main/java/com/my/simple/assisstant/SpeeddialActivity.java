package com.my.simple.assisstant;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;
import android.net.Uri;
import android.app.Activity;
import android.content.SharedPreferences;
import android.view.View;

public class SpeeddialActivity extends AppCompatActivity {
	
	
	private Toolbar _toolbar;
	private String sdi1 = "";
	private String sdi2 = "";
	private String sdi3 = "";
	private String sdi4 = "";
	private String sdi5 = "";
	
	private ScrollView vscroll1;
	private LinearLayout linear3;
	private TextView textview3;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private LinearLayout linear8;
	private Button sd1;
	private EditText s1;
	private Button st1;
	private Button sd2;
	private EditText s2;
	private Button st2;
	private Button sd3;
	private EditText s3;
	private Button st3;
	private Button sd4;
	private EditText s4;
	private Button st4;
	private Button sd5;
	private EditText s5;
	private Button st5;
	
	private Intent i = new Intent();
	private SharedPreferences f;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.speeddial);
		initialize();
		initializeLogic();
	}
	
	private void initialize() {
		
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		textview3 = (TextView) findViewById(R.id.textview3);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		sd1 = (Button) findViewById(R.id.sd1);
		s1 = (EditText) findViewById(R.id.s1);
		st1 = (Button) findViewById(R.id.st1);
		sd2 = (Button) findViewById(R.id.sd2);
		s2 = (EditText) findViewById(R.id.s2);
		st2 = (Button) findViewById(R.id.st2);
		sd3 = (Button) findViewById(R.id.sd3);
		s3 = (EditText) findViewById(R.id.s3);
		st3 = (Button) findViewById(R.id.st3);
		sd4 = (Button) findViewById(R.id.sd4);
		s4 = (EditText) findViewById(R.id.s4);
		st4 = (Button) findViewById(R.id.st4);
		sd5 = (Button) findViewById(R.id.sd5);
		s5 = (EditText) findViewById(R.id.s5);
		st5 = (Button) findViewById(R.id.st5);
		f = getSharedPreferences("abc", Activity.MODE_PRIVATE);
		
		sd1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				i.setAction(Intent.ACTION_CALL);
				i.setData(Uri.parse("tel:".concat(f.getString(sd1.getText().toString(), ""))));
				startActivity(i);
				SketchwareUtil.showMessage(getApplicationContext(), f.getString(sd1.getText().toString(), ""));
			}
		});
		
		st1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				f.edit().putString(sd1.getText().toString(), s1.getText().toString()).commit();
			}
		});
		
		sd2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				i.setAction(Intent.ACTION_CALL);
				i.setData(Uri.parse("tel:".concat(f.getString(sd2.getText().toString(), ""))));
				startActivity(i);
				SketchwareUtil.showMessage(getApplicationContext(), f.getString(sd2.getText().toString(), ""));
			}
		});
		
		st2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				f.edit().putString(sd2.getText().toString(), s2.getText().toString()).commit();
			}
		});
		
		sd3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				i.setAction(Intent.ACTION_CALL);
				i.setData(Uri.parse("tel:".concat(f.getString(sd3.getText().toString(), ""))));
				startActivity(i);
				SketchwareUtil.showMessage(getApplicationContext(), f.getString(sd3.getText().toString(), ""));
			}
		});
		
		st3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				f.edit().putString(sd3.getText().toString(), s3.getText().toString()).commit();
			}
		});
		
		sd4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				i.setAction(Intent.ACTION_CALL);
				i.setData(Uri.parse("tel:".concat(f.getString(sd4.getText().toString(), ""))));
				startActivity(i);
				SketchwareUtil.showMessage(getApplicationContext(), f.getString(sd4.getText().toString(), ""));
			}
		});
		
		st4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				f.edit().putString(sd4.getText().toString(), s4.getText().toString()).commit();
			}
		});
		
		sd5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				i.setAction(Intent.ACTION_CALL);
				i.setData(Uri.parse("tel:".concat(f.getString(sd5.getText().toString(), ""))));
				startActivity(i);
				SketchwareUtil.showMessage(getApplicationContext(), f.getString(sd5.getText().toString(), ""));
			}
		});
		
		st5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				f.edit().putString(sd5.getText().toString(), s5.getText().toString()).commit();
			}
		});
	}
	private void initializeLogic() {
		setTitle("Speed Dial");
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
