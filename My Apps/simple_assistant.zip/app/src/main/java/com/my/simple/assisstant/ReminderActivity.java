package com.my.simple.assisstant;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import java.util.ArrayList;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import java.util.Timer;
import java.util.TimerTask;
import android.app.AlertDialog;
import android.content.DialogInterface;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import android.content.Intent;
import android.net.Uri;
import android.view.View;

public class ReminderActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private Toolbar _toolbar;
	private double i = 0;
	private double j = 0;
	private double y = 0;
	private double m = 0;
	private double date = 0;
	
	private ArrayList<String> Hour = new ArrayList<>();
	private ArrayList<String> Minute = new ArrayList<>();
	private ArrayList<String> year = new ArrayList<>();
	private ArrayList<String> month = new ArrayList<>();
	private ArrayList<String> datel = new ArrayList<>();
	
	private ScrollView vscroll2;
	private LinearLayout linear9;
	private TextView textview12;
	private EditText edittext10;
	private TextView textview13;
	private LinearLayout linear14;
	private LinearLayout linear13;
	private TextView textview14;
	private LinearLayout linear12;
	private LinearLayout linear11;
	private Button button3;
	private TextView textview20;
	private TextView textview19;
	private TextView textview18;
	private Spinner spinner3;
	private Spinner spinner4;
	private Spinner spinner5;
	private TextView textview15;
	private TextView textview16;
	private Spinner spinner1;
	private TextView textview17;
	private Spinner spinner2;
	
	private TimerTask t;
	private AlertDialog.Builder d;
	private Calendar c1 = Calendar.getInstance();
	private Calendar c2 = Calendar.getInstance();
	private Intent it = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.reminder);
		initialize();
		initializeLogic();
	}
	
	private void initialize() {
		
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		vscroll2 = (ScrollView) findViewById(R.id.vscroll2);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		textview12 = (TextView) findViewById(R.id.textview12);
		edittext10 = (EditText) findViewById(R.id.edittext10);
		textview13 = (TextView) findViewById(R.id.textview13);
		linear14 = (LinearLayout) findViewById(R.id.linear14);
		linear13 = (LinearLayout) findViewById(R.id.linear13);
		textview14 = (TextView) findViewById(R.id.textview14);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		button3 = (Button) findViewById(R.id.button3);
		textview20 = (TextView) findViewById(R.id.textview20);
		textview19 = (TextView) findViewById(R.id.textview19);
		textview18 = (TextView) findViewById(R.id.textview18);
		spinner3 = (Spinner) findViewById(R.id.spinner3);
		spinner4 = (Spinner) findViewById(R.id.spinner4);
		spinner5 = (Spinner) findViewById(R.id.spinner5);
		textview15 = (TextView) findViewById(R.id.textview15);
		textview16 = (TextView) findViewById(R.id.textview16);
		spinner1 = (Spinner) findViewById(R.id.spinner1);
		textview17 = (TextView) findViewById(R.id.textview17);
		spinner2 = (Spinner) findViewById(R.id.spinner2);
		d = new AlertDialog.Builder(this);
		
		button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				c1 = Calendar.getInstance();
				c2.set(Calendar.YEAR, (int)(spinner3.getSelectedItemPosition()));
				c2.set(Calendar.MONTH, (int)(spinner4.getSelectedItemPosition()));
				c2.set(Calendar.DAY_OF_MONTH, (int)(spinner5.getSelectedItemPosition()));
				c2.set(Calendar.HOUR, (int)(spinner1.getSelectedItemPosition()));
				c2.set(Calendar.MINUTE, (int)(spinner2.getSelectedItemPosition()));
				c2.set(Calendar.SECOND, (int)(0));
				if ((long)(c2.getTimeInMillis() - c1.getTimeInMillis()) > 0) {
					t = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									d.setMessage(edittext10.getText().toString());
									d.create().show();
								}
							});
						}
					};
					_timer.schedule(t, (int)((long)(c2.getTimeInMillis() - c1.getTimeInMillis())));
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "Enter proper time and date");
				}
			}
		});
	}
	private void initializeLogic() {
		setTitle("Reminder");
		i = 0;
		j = 0;
		for(int _repeat12 = 0; _repeat12 < (int)(24); _repeat12++) {
			Hour.add((int)(i), String.valueOf((long)(i)));
			i++;
		}
		for(int _repeat18 = 0; _repeat18 < (int)(60); _repeat18++) {
			Minute.add((int)(j), String.valueOf((long)(j)));
			j++;
		}
		spinner1.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, Hour));
		spinner2.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, Minute));
		c1 = Calendar.getInstance();
		
		c2.set(Calendar.HOUR, (int)(spinner1.getSelectedItemPosition()));
		c2.set(Calendar.MINUTE, (int)(spinner2.getSelectedItemPosition()));
		y = 1990;
		i = 0;
		for(int _repeat37 = 0; _repeat37 < (int)(100); _repeat37++) {
			year.add((int)(i), String.valueOf((long)(y)));
			y++;
			i++;
		}
		spinner3.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, year));
		c2.set(Calendar.YEAR, (int)(spinner3.getSelectedItemPosition()));
		y = spinner3.getSelectedItemPosition();
		m = 1;
		i = 0;
		for(int _repeat47 = 0; _repeat47 < (int)(12); _repeat47++) {
			month.add((int)(i), String.valueOf((long)(m)));
			m++;
			i++;
		}
		spinner4.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, month));
		c2.set(Calendar.MONTH, (int)(spinner4.getSelectedItemPosition()));
		m = spinner4.getSelectedItemPosition();
		if (((y % 4) == 0) && (m == 2)) {
			i = 0;
			for(int _repeat71 = 0; _repeat71 < (int)(29); _repeat71++) {
				datel.add((int)(i), String.valueOf((long)(i + 1)));
				i++;
			}
			spinner5.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, datel));
		}
		else {
			if ((((m == 1) && (m == 3)) || ((m == 5) || (m == 7))) || (((m == 8) || (m == 10)) || (m == 12))) {
				i = 0;
				for(int _repeat124 = 0; _repeat124 < (int)(31); _repeat124++) {
					datel.add((int)(i), String.valueOf((long)(i + 1)));
					i++;
				}
				spinner5.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, datel));
			}
			else {
				if (((m == 4) && (m == 6)) || ((m == 9) || (m == 11))) {
					i = 0;
					for(int _repeat132 = 0; _repeat132 < (int)(30); _repeat132++) {
						datel.add((int)(i), String.valueOf((long)(i + 1)));
						i++;
					}
					spinner5.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, datel));
				}
				else {
					i = 0;
					for(int _repeat140 = 0; _repeat140 < (int)(28); _repeat140++) {
						datel.add((int)(i), String.valueOf((long)(i + 1)));
						i++;
					}
					spinner5.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, datel));
				}
			}
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
