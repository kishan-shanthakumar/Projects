package com.my.simple.assisstant;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import android.content.Intent;
import android.net.Uri;
import android.app.Activity;
import android.content.SharedPreferences;
import android.app.AlertDialog;
import android.content.DialogInterface;
import java.util.Timer;
import java.util.TimerTask;
import android.animation.ObjectAnimator;
import android.view.animation.LinearInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.View;

public class MainActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private Toolbar _toolbar;
	
	private ScrollView vscroll2;
	private LinearLayout linear23;
	private TextView textview4;
	private LinearLayout linear43;
	private LinearLayout linear24;
	private LinearLayout linear25;
	private LinearLayout linear26;
	private LinearLayout linear27;
	private LinearLayout linear28;
	private LinearLayout linear29;
	private LinearLayout linear30;
	private TextView textview6;
	private TextView textview7;
	private TextView textview5;
	private LinearLayout linear31;
	private LinearLayout linear34;
	private Button pd;
	private Button reminder;
	private LinearLayout linear32;
	private LinearLayout linear35;
	private Button diary;
	private Button speeddial;
	private LinearLayout linear33;
	private LinearLayout linear36;
	private Button map;
	private Button calc;
	private LinearLayout linear37;
	private LinearLayout linear40;
	private Button button20;
	private Button button23;
	private LinearLayout linear38;
	private LinearLayout linear41;
	private Button button21;
	private Button button24;
	private LinearLayout linear39;
	private LinearLayout linear42;
	private Button help;
	private Button instructions;
	
	private Calendar c = Calendar.getInstance();
	private Intent i = new Intent();
	private SharedPreferences f;
	private AlertDialog.Builder d;
	private TimerTask t;
	private ObjectAnimator o = new ObjectAnimator();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize();
		initializeLogic();
	}
	
	private void initialize() {
		
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		vscroll2 = (ScrollView) findViewById(R.id.vscroll2);
		linear23 = (LinearLayout) findViewById(R.id.linear23);
		textview4 = (TextView) findViewById(R.id.textview4);
		linear43 = (LinearLayout) findViewById(R.id.linear43);
		linear24 = (LinearLayout) findViewById(R.id.linear24);
		linear25 = (LinearLayout) findViewById(R.id.linear25);
		linear26 = (LinearLayout) findViewById(R.id.linear26);
		linear27 = (LinearLayout) findViewById(R.id.linear27);
		linear28 = (LinearLayout) findViewById(R.id.linear28);
		linear29 = (LinearLayout) findViewById(R.id.linear29);
		linear30 = (LinearLayout) findViewById(R.id.linear30);
		textview6 = (TextView) findViewById(R.id.textview6);
		textview7 = (TextView) findViewById(R.id.textview7);
		textview5 = (TextView) findViewById(R.id.textview5);
		linear31 = (LinearLayout) findViewById(R.id.linear31);
		linear34 = (LinearLayout) findViewById(R.id.linear34);
		pd = (Button) findViewById(R.id.pd);
		reminder = (Button) findViewById(R.id.reminder);
		linear32 = (LinearLayout) findViewById(R.id.linear32);
		linear35 = (LinearLayout) findViewById(R.id.linear35);
		diary = (Button) findViewById(R.id.diary);
		speeddial = (Button) findViewById(R.id.speeddial);
		linear33 = (LinearLayout) findViewById(R.id.linear33);
		linear36 = (LinearLayout) findViewById(R.id.linear36);
		map = (Button) findViewById(R.id.map);
		calc = (Button) findViewById(R.id.calc);
		linear37 = (LinearLayout) findViewById(R.id.linear37);
		linear40 = (LinearLayout) findViewById(R.id.linear40);
		button20 = (Button) findViewById(R.id.button20);
		button23 = (Button) findViewById(R.id.button23);
		linear38 = (LinearLayout) findViewById(R.id.linear38);
		linear41 = (LinearLayout) findViewById(R.id.linear41);
		button21 = (Button) findViewById(R.id.button21);
		button24 = (Button) findViewById(R.id.button24);
		linear39 = (LinearLayout) findViewById(R.id.linear39);
		linear42 = (LinearLayout) findViewById(R.id.linear42);
		help = (Button) findViewById(R.id.help);
		instructions = (Button) findViewById(R.id.instructions);
		f = getSharedPreferences("abc", Activity.MODE_PRIVATE);
		d = new AlertDialog.Builder(this);
		
		pd.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				i.setClass(getApplicationContext(), PerdetActivity.class);
				startActivity(i);
			}
		});
		
		reminder.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				i.setClass(getApplicationContext(), ReminderActivity.class);
				startActivity(i);
			}
		});
		
		diary.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				i.setClass(getApplicationContext(), PassdiaryActivity.class);
				startActivity(i);
			}
		});
		
		speeddial.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				i.setClass(getApplicationContext(), SpeeddialActivity.class);
				startActivity(i);
			}
		});
		
		map.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				i.setClass(getApplicationContext(), MapActivity.class);
				startActivity(i);
			}
		});
		
		calc.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				
			}
		});
		
		button20.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				
			}
		});
		
		button23.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				
			}
		});
		
		button21.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				
			}
		});
		
		button24.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				
			}
		});
		
		help.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				i.setClass(getApplicationContext(), HelpActivity.class);
				startActivity(i);
			}
		});
		
		instructions.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				i.setClass(getApplicationContext(), InstructionsActivity.class);
				startActivity(i);
			}
		});
	}
	private void initializeLogic() {
		t = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						c = Calendar.getInstance();
						textview7.setText(new SimpleDateFormat("MMM/dd/yyyy hh:mm:ss").format(c.getTime()));
					}
				});
			}
		};
		_timer.scheduleAtFixedRate(t, (int)(0), (int)(1000));
		SketchwareUtil.showMessage(getApplicationContext(), "You need to be online for all the features to work");
		d.setMessage("This application is a simple assistant to help you with things. This is a multi-purpose app for many things at one place. Press on an option follow the directions to get desired help.");
		d.create().show();
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
