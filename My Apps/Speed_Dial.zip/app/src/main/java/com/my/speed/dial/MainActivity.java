package com.my.speed.dial;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.app.Activity;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;
import android.net.Uri;
import android.content.SharedPreferences;
import android.animation.ObjectAnimator;
import android.view.animation.LinearInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.View;

public class MainActivity extends Activity {
	
	
	private String sdi1 = "";
	private String sdi2 = "";
	private String sdi3 = "";
	private String sdi4 = "";
	private String sdi5 = "";
	
	private ScrollView vscroll1;
	private LinearLayout linear1;
	private TextView textview1;
	private LinearLayout linear2;
	private LinearLayout linear6;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear12;
	private Button sd1;
	private EditText s1;
	private LinearLayout linear16;
	private Button sd2;
	private EditText s2;
	private LinearLayout linear13;
	private Button sd3;
	private EditText s3;
	private LinearLayout linear14;
	private Button sd4;
	private EditText s4;
	private LinearLayout linear18;
	private Button sd5;
	private EditText s5;
	
	private Intent i = new Intent();
	private SharedPreferences f;
	private ObjectAnimator oa = new ObjectAnimator();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize();
		initializeLogic();
	}
	
	private void initialize() {
		
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		textview1 = (TextView) findViewById(R.id.textview1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		sd1 = (Button) findViewById(R.id.sd1);
		s1 = (EditText) findViewById(R.id.s1);
		linear16 = (LinearLayout) findViewById(R.id.linear16);
		sd2 = (Button) findViewById(R.id.sd2);
		s2 = (EditText) findViewById(R.id.s2);
		linear13 = (LinearLayout) findViewById(R.id.linear13);
		sd3 = (Button) findViewById(R.id.sd3);
		s3 = (EditText) findViewById(R.id.s3);
		linear14 = (LinearLayout) findViewById(R.id.linear14);
		sd4 = (Button) findViewById(R.id.sd4);
		s4 = (EditText) findViewById(R.id.s4);
		linear18 = (LinearLayout) findViewById(R.id.linear18);
		sd5 = (Button) findViewById(R.id.sd5);
		s5 = (EditText) findViewById(R.id.s5);
		f = getSharedPreferences("abc", Activity.MODE_PRIVATE);
		
		sd1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				if (s1.getText().toString().length() > 0) {
					sdi1 = s1.getText().toString();
					f.edit().putString(sd1.getText().toString(), s1.getText().toString()).commit();
					i.setAction(Intent.ACTION_CALL);
					i.setData(Uri.parse("tel:".concat(sdi1)));
					startActivity(i);
				}
				else {
					i.setAction(Intent.ACTION_CALL);
					i.setData(Uri.parse("tel:".concat(f.getString(sd1.getText().toString(), ""))));
					startActivity(i);
				}
			}
		});
		
		sd2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				if (s2.getText().toString().length() > 0) {
					sdi2 = s2.getText().toString();
					f.edit().putString(sd2.getText().toString(), s2.getText().toString()).commit();
					i.setAction(Intent.ACTION_CALL);
					i.setData(Uri.parse("tel:".concat(sdi2)));
					startActivity(i);
				}
				else {
					i.setAction(Intent.ACTION_CALL);
					i.setData(Uri.parse("tel:".concat(f.getString(sd2.getText().toString(), ""))));
					startActivity(i);
				}
			}
		});
		
		sd3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				if (s3.getText().toString().length() > 0) {
					sdi3 = s3.getText().toString();
					f.edit().putString(sd3.getText().toString(), s3.getText().toString()).commit();
					i.setAction(Intent.ACTION_CALL);
					i.setData(Uri.parse("tel:".concat(sdi3)));
					startActivity(i);
				}
				else {
					i.setAction(Intent.ACTION_CALL);
					i.setData(Uri.parse("tel:".concat(f.getString(sd3.getText().toString(), ""))));
					startActivity(i);
				}
			}
		});
		
		sd4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				if (s4.getText().toString().length() > 0) {
					sdi4 = s4.getText().toString();
					f.edit().putString(sd4.getText().toString(), s4.getText().toString()).commit();
					i.setAction(Intent.ACTION_CALL);
					i.setData(Uri.parse("tel:".concat(sdi4)));
					startActivity(i);
				}
				else {
					i.setAction(Intent.ACTION_CALL);
					i.setData(Uri.parse("tel:".concat(f.getString(sd4.getText().toString(), ""))));
					startActivity(i);
				}
			}
		});
		
		sd5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				if (s5.getText().toString().length() > 0) {
					sdi5 = s5.getText().toString();
					f.edit().putString(sd5.getText().toString(), s5.getText().toString()).commit();
					i.setAction(Intent.ACTION_CALL);
					i.setData(Uri.parse("tel:".concat(sdi5)));
					startActivity(i);
				}
				else {
					i.setAction(Intent.ACTION_CALL);
					i.setData(Uri.parse("tel:".concat(f.getString(sd5.getText().toString(), ""))));
					startActivity(i);
				}
			}
		});
	}
	private void initializeLogic() {
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
