package com.my.equations;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.app.Activity;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.content.Intent;
import android.net.Uri;
import android.content.SharedPreferences;
import android.view.View;
import java.text.DecimalFormat;

public class QuadActivity extends Activity {
	
	
	private double a = 0;
	private double b = 0;
	private double c = 0;
	private double d = 0;
	private double x1 = 0;
	private double x2 = 0;
	private String a1 = "";
	private String b1 = "";
	private String c1 = "";
	private String d1 = "";
	private String x11 = "";
	private String x21 = "";
	
	private ScrollView vscroll1;
	private LinearLayout linear1;
	private TextView textview4;
	private TextView textview5;
	private TextView textview6;
	private EditText ai;
	private TextView textview7;
	private EditText bi;
	private TextView textview8;
	private EditText ci;
	private Button run;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private TextView textview9;
	private TextView remarks;
	private TextView textview11;
	private TextView discriminant;
	private TextView textview13;
	private TextView root1;
	private TextView textview15;
	private TextView root2;
	private Button back;
	
	private Intent fi = new Intent();
	private SharedPreferences fs;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.quad);
		initialize();
		initializeLogic();
	}
	
	private void initialize() {
		
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		textview4 = (TextView) findViewById(R.id.textview4);
		textview5 = (TextView) findViewById(R.id.textview5);
		textview6 = (TextView) findViewById(R.id.textview6);
		ai = (EditText) findViewById(R.id.ai);
		textview7 = (TextView) findViewById(R.id.textview7);
		bi = (EditText) findViewById(R.id.bi);
		textview8 = (TextView) findViewById(R.id.textview8);
		ci = (EditText) findViewById(R.id.ci);
		run = (Button) findViewById(R.id.run);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		textview9 = (TextView) findViewById(R.id.textview9);
		remarks = (TextView) findViewById(R.id.remarks);
		textview11 = (TextView) findViewById(R.id.textview11);
		discriminant = (TextView) findViewById(R.id.discriminant);
		textview13 = (TextView) findViewById(R.id.textview13);
		root1 = (TextView) findViewById(R.id.root1);
		textview15 = (TextView) findViewById(R.id.textview15);
		root2 = (TextView) findViewById(R.id.root2);
		back = (Button) findViewById(R.id.back);
		fs = getSharedPreferences("abc", Activity.MODE_PRIVATE);
		
		run.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				if (((ai.getText().toString().length() > 0) && (bi.getText().toString().length() > 0)) && (ci.getText().toString().length() > 0)) {
					a1 = ai.getText().toString();
					a = Double.parseDouble(a1);
					if (a == 0) {
						SketchwareUtil.showMessage(getApplicationContext(), "Enter proper equation");
					}
					else {
						b1 = bi.getText().toString();
						b = Double.parseDouble(b1);
						c1 = ci.getText().toString();
						c = Double.parseDouble(c1);
						d = (b * b) - (4 * (a * c));
						d1 = String.valueOf(d);
						discriminant.setText(d1);
						if (d < 0) {
							remarks.setText("Imaginary Roots");
							root1.setText(String.valueOf((0 - b) / (2 * a)).concat("+").concat(String.valueOf(Math.sqrt(0 - d) / (2 * a)).concat("i")));
							root2.setText(String.valueOf((0 - b) / (2 * a)).concat("-").concat(String.valueOf(Math.sqrt(0 - d) / (2 * a)).concat("i")));
						}
						else {
							remarks.setText("Real Roots");
							if (d > 0) {
								x1 = ((0 - b) / (2 * a)) + (Math.sqrt(d) / (2 * a));
								x2 = ((0 - b) / (2 * a)) - (Math.sqrt(d) / (2 * a));
							}
							else {
								x1 = (0 - b) / (2 * a);
								x2 = (0 - b) / (2 * a);
							}
							x11 = String.valueOf(x1);
							x21 = String.valueOf(x2);
							root1.setText(x11);
							root2.setText(x21);
						}
					}
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "Enter all the values and then press enter");
				}
			}
		});
		
		back.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				fi.setClass(getApplicationContext(), MainActivity.class);
				startActivity(fi);
			}
		});
	}
	private void initializeLogic() {
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
