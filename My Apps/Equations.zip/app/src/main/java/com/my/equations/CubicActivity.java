package com.my.equations;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.app.Activity;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.content.Intent;
import android.net.Uri;
import android.content.SharedPreferences;
import android.view.View;
import java.text.DecimalFormat;

public class CubicActivity extends Activity {
	
	
	private double a = 0;
	private double b = 0;
	private double c = 0;
	private double d = 0;
	private double f = 0;
	private double g = 0;
	private double h = 0;
	private double i = 0;
	private double j = 0;
	private double k = 0;
	private double l = 0;
	private double m = 0;
	private double n = 0;
	private double p = 0;
	private double r = 0;
	private double s = 0;
	private double t = 0;
	private double u = 0;
	private double x1 = 0;
	private double x2 = 0;
	private double x3 = 0;
	private double x = 0;
	private double x0 = 0;
	private double disc = 0;
	private double rootx = 0;
	
	private ScrollView vscroll2;
	private LinearLayout linear1;
	private TextView textview1;
	private TextView textview2;
	private TextView textview3;
	private EditText ac;
	private TextView textview4;
	private EditText bc;
	private TextView textview5;
	private EditText cc;
	private TextView textview6;
	private EditText dc;
	private Button enter;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private Button back;
	private TextView textview7;
	private TextView root1;
	private TextView textview9;
	private TextView root2;
	private TextView textview11;
	private TextView root3;
	
	private Intent fi = new Intent();
	private SharedPreferences fs;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.cubic);
		initialize();
		initializeLogic();
	}
	
	private void initialize() {
		
		vscroll2 = (ScrollView) findViewById(R.id.vscroll2);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		textview1 = (TextView) findViewById(R.id.textview1);
		textview2 = (TextView) findViewById(R.id.textview2);
		textview3 = (TextView) findViewById(R.id.textview3);
		ac = (EditText) findViewById(R.id.ac);
		textview4 = (TextView) findViewById(R.id.textview4);
		bc = (EditText) findViewById(R.id.bc);
		textview5 = (TextView) findViewById(R.id.textview5);
		cc = (EditText) findViewById(R.id.cc);
		textview6 = (TextView) findViewById(R.id.textview6);
		dc = (EditText) findViewById(R.id.dc);
		enter = (Button) findViewById(R.id.enter);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		back = (Button) findViewById(R.id.back);
		textview7 = (TextView) findViewById(R.id.textview7);
		root1 = (TextView) findViewById(R.id.root1);
		textview9 = (TextView) findViewById(R.id.textview9);
		root2 = (TextView) findViewById(R.id.root2);
		textview11 = (TextView) findViewById(R.id.textview11);
		root3 = (TextView) findViewById(R.id.root3);
		fs = getSharedPreferences("abc", Activity.MODE_PRIVATE);
		
		enter.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				a = Double.parseDouble(ac.getText().toString());
				b = Double.parseDouble(bc.getText().toString());
				c = Double.parseDouble(cc.getText().toString());
				d = Double.parseDouble(dc.getText().toString());
				if (!(a == 0)) {
					if (!(d == 0)) {
						f = (((3 * c) / a) - ((b * b) / (a * a))) / 3;
						g = ((((2 * Math.pow(b, 3)) / Math.pow(a, 3)) - (((9 * b) * c) / (a * a))) + ((27 * d) / a)) / 27;
						h = (Math.pow(g, 2) / 4) + (Math.pow(f, 3) / 27);
						if (((f == 0) && (g == 0)) && (h == 0)) {
							root1.setText(String.valueOf(-1 * Math.pow(d / a, 1 / 3)));
							root2.setText(String.valueOf(-1 * Math.pow(d / a, 1 / 3)));
							root3.setText(String.valueOf(-1 * Math.pow(d / a, 1 / 3)));
						}
						else {
							x = 0;
							x1 = (((a * x) * (x * x)) + ((b * x) * x)) + ((c * x) + d);
							x0 = (((3 * a) * (x * x)) + ((2 * b) * x)) + c;
							while(true) {
								x = x - (x1 / x0);
								x1 = (((a * x) * (x * x)) + ((b * x) * x)) + ((c * x) + d);
								x0 = (((3 * a) * (x * x)) + ((2 * b) * x)) + c;
								if (Math.abs(x1 / x0) < Math.pow(10, -15)) {
									break;
								}
							}
							x1 = x;
							disc = Math.pow((a * x1) + b, 2) - (4 * (a * ((((a * x1) + b) * x1) + c)));
							if (disc < 0) {
								root2.setText(String.valueOf((0 - ((a * x1) + b)) / (2 * a)).concat("+").concat(String.valueOf(Math.sqrt(0 - disc) / (2 * a)).concat("i")));
								root3.setText(String.valueOf((0 - ((a * x1) + b)) / (2 * a)).concat("-").concat(String.valueOf(Math.sqrt(0 - disc) / (2 * a)).concat("i")));
								root1.setText(String.valueOf(x1));
							}
							else {
								x2 = ((0 - ((a * x1) + b)) / (2 * a)) + (Math.sqrt(disc) / (2 * a));
								x3 = ((0 - ((a * x1) + b)) / (2 * a)) - (Math.sqrt(disc) / (2 * a));
								root1.setText(String.valueOf(x1));
								root2.setText(String.valueOf(x2));
								root3.setText(String.valueOf(x3));
							}
						}
					}
					else {
						disc = (b * b) - ((4 * a) * c);
						if (disc < 0) {
							root1.setText(String.valueOf((0 - b) / (2 * a)).concat("+").concat(String.valueOf(Math.sqrt(0 - disc) / (2 * a)).concat("i")));
							root2.setText(String.valueOf((0 - b) / (2 * a)).concat("-").concat(String.valueOf(Math.sqrt(0 - disc) / (2 * a)).concat("i")));
							root3.setText("0.0");
						}
						else {
							x1 = ((0 - b) / (2 * a)) + (Math.sqrt(disc) / (2 * a));
							x2 = ((0 - b) / (2 * a)) - (Math.sqrt(disc) / (2 * a));
							root1.setText(String.valueOf(x1));
							root2.setText(String.valueOf(x2));
							root3.setText("0.0");
						}
					}
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "Enter proper equation");
				}
			}
		});
		
		back.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				fi.setClass(getApplicationContext(), MainActivity.class);
				startActivity(fi);
			}
		});
	}
	private void initializeLogic() {
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
