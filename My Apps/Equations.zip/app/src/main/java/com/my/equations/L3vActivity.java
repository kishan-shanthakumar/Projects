package com.my.equations;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.app.Activity;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;
import android.net.Uri;
import android.content.SharedPreferences;
import android.view.View;
import java.text.DecimalFormat;

public class L3vActivity extends Activity {
	
	
	private double a1 = 0;
	private double a2 = 0;
	private double a3 = 0;
	private double b1 = 0;
	private double b2 = 0;
	private double b3 = 0;
	private double c1 = 0;
	private double c2 = 0;
	private double c3 = 0;
	private double d1 = 0;
	private double d2 = 0;
	private double d3 = 0;
	private double det = 0;
	private double cfa1 = 0;
	private double cfa2 = 0;
	private double cfa3 = 0;
	private double cfb1 = 0;
	private double cfb2 = 0;
	private double cfb3 = 0;
	private double cfc1 = 0;
	private double cfc2 = 0;
	private double cfc3 = 0;
	
	private LinearLayout linear1;
	private TextView textview1;
	private TextView textview2;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear7;
	private LinearLayout linear8;
	private LinearLayout linear9;
	private Button run;
	private Button back;
	private TextView textview3;
	private EditText a1v;
	private TextView textview4;
	private EditText a2v;
	private TextView textview5;
	private EditText a3v;
	private TextView textview6;
	private EditText b1v;
	private TextView textview7;
	private EditText b2v;
	private TextView textview8;
	private EditText b3v;
	private TextView textview9;
	private EditText c1v;
	private TextView textview10;
	private EditText c2v;
	private TextView textview11;
	private EditText c3v;
	private TextView textview12;
	private EditText d1v;
	private TextView textview13;
	private EditText d2v;
	private TextView textview14;
	private EditText d3v;
	private TextView textview17;
	private TextView xv;
	private TextView textview19;
	private TextView yv;
	private TextView textview21;
	private TextView zv;
	
	private Intent fi = new Intent();
	private SharedPreferences fs;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.l3v);
		initialize();
		initializeLogic();
	}
	
	private void initialize() {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		textview1 = (TextView) findViewById(R.id.textview1);
		textview2 = (TextView) findViewById(R.id.textview2);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		run = (Button) findViewById(R.id.run);
		back = (Button) findViewById(R.id.back);
		textview3 = (TextView) findViewById(R.id.textview3);
		a1v = (EditText) findViewById(R.id.a1v);
		textview4 = (TextView) findViewById(R.id.textview4);
		a2v = (EditText) findViewById(R.id.a2v);
		textview5 = (TextView) findViewById(R.id.textview5);
		a3v = (EditText) findViewById(R.id.a3v);
		textview6 = (TextView) findViewById(R.id.textview6);
		b1v = (EditText) findViewById(R.id.b1v);
		textview7 = (TextView) findViewById(R.id.textview7);
		b2v = (EditText) findViewById(R.id.b2v);
		textview8 = (TextView) findViewById(R.id.textview8);
		b3v = (EditText) findViewById(R.id.b3v);
		textview9 = (TextView) findViewById(R.id.textview9);
		c1v = (EditText) findViewById(R.id.c1v);
		textview10 = (TextView) findViewById(R.id.textview10);
		c2v = (EditText) findViewById(R.id.c2v);
		textview11 = (TextView) findViewById(R.id.textview11);
		c3v = (EditText) findViewById(R.id.c3v);
		textview12 = (TextView) findViewById(R.id.textview12);
		d1v = (EditText) findViewById(R.id.d1v);
		textview13 = (TextView) findViewById(R.id.textview13);
		d2v = (EditText) findViewById(R.id.d2v);
		textview14 = (TextView) findViewById(R.id.textview14);
		d3v = (EditText) findViewById(R.id.d3v);
		textview17 = (TextView) findViewById(R.id.textview17);
		xv = (TextView) findViewById(R.id.xv);
		textview19 = (TextView) findViewById(R.id.textview19);
		yv = (TextView) findViewById(R.id.yv);
		textview21 = (TextView) findViewById(R.id.textview21);
		zv = (TextView) findViewById(R.id.zv);
		fs = getSharedPreferences("abc", Activity.MODE_PRIVATE);
		
		run.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				a1 = Double.parseDouble(a1v.getText().toString());
				a2 = Double.parseDouble(a2v.getText().toString());
				a3 = Double.parseDouble(a3v.getText().toString());
				b1 = Double.parseDouble(b1v.getText().toString());
				b2 = Double.parseDouble(b2v.getText().toString());
				b3 = Double.parseDouble(b3v.getText().toString());
				c1 = Double.parseDouble(c1v.getText().toString());
				c2 = Double.parseDouble(c2v.getText().toString());
				c3 = Double.parseDouble(c3v.getText().toString());
				d1 = Double.parseDouble(d1v.getText().toString());
				d2 = Double.parseDouble(d2v.getText().toString());
				d3 = Double.parseDouble(d3v.getText().toString());
				det = ((a1 * ((b2 * c3) - (b3 * c2))) + (c1 * ((a2 * b3) - (a3 * b2)))) - (b1 * ((a2 * c3) - (a3 * c2)));
				if (!(det == 0)) {
					cfa1 = (b2 * c3) - (b3 * c2);
					cfa2 = (a3 * c2) - (a2 * c3);
					cfa3 = (a2 * b3) - (a3 * b2);
					cfb1 = (b3 * c1) - (b1 * c3);
					cfb2 = (a1 * c3) - (a3 * c1);
					cfb3 = (a3 * b1) - (a1 * b3);
					cfc1 = (b1 * c2) - (b2 * c1);
					cfc2 = (a2 * c1) - (a1 * c2);
					cfc3 = (a1 * b2) - (a2 * b1);
					xv.setText(String.valueOf((((cfa1 * d1) + (cfb1 * d2)) + (cfc1 * d3)) / det));
					yv.setText(String.valueOf((((cfa2 * d1) + (cfb2 * d2)) + (cfc2 * d3)) / det));
					zv.setText(String.valueOf((((cfa3 * d1) + (cfb3 * d2)) + (cfc3 * d3)) / det));
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "Enter proper equation");
				}
			}
		});
		
		back.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				fi.setClass(getApplicationContext(), MainActivity.class);
				startActivity(fi);
			}
		});
	}
	private void initializeLogic() {
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
